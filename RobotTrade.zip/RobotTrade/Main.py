import ctypes
import time
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import messagebox

import MetaTrader5 as mt5

from CandleAnalyzer import CandleAnalyzer
from SignalManagement import SignalManagement
from Simulador import Simulador
from UUIDManager import UUIDManager

num_candles = 30
qtd_minutes = 20

def executar_robot():
    try:
        # Campos básicos
        login = int(entry_login.get())
        senha = entry_senha.get()
        servidor = entry_servidor.get()
        symbol = entry_symbol.get()
        volume = float(entry_volume.get())
        timeframe_str = entry_timeframe.get().upper()
        timeframe = getattr(mt5, f"TIMEFRAME_{timeframe_str}")
        datainicio = datetime.strptime(data_inicio.get(), "%d/%m/%Y")
        datafim = datetime.strptime(data_fim.get(), "%d/%m/%Y")

        # Campos adicionais numéricos
        martingale = int(entry_martingale.get())
        stop_minimo = int(entry_stop_minimo.get())
        perda_diaria = int(entry_perda_diaria.get())
        percent_risk = int(entry_percent_risk.get())

        # Criar analisador
        UUIDManager().validarUUID(var_credencial.get())
        analyzer = CandleAnalyzer(
            login=login,
            senha=senha,
            servidor=servidor,
            symbol=symbol,
            timeframe=timeframe,
            volume=volume,
            enableMACD=var_macd.get(),
            enableCCI=var_cci.get(),
            enableRSI=var_rsi.get(),
            enableBollinger=var_bollinger.get(),
            enablePatternAnalysis=var_pattern.get(),
            enableVerifyDivergence=var_divergence.get(),
            enableMartingale=martingale,
            stopMinimo=stop_minimo,
            maximoPerdaDiaria=perda_diaria,
            percentRiskAndProfit=percent_risk
        )
        print(f"Iniciando")
        if var_enable_sim.get():
            sim = Simulador(analyzer, start_date=datainicio, end_date=datafim)
            sim.salvar_estatisticas_excel()
        else:
            _impedir_reposo()
            signalManagement = SignalManagement()
            while True:
                print("Robo em execucao")
                dataframe = analyzer.recuperarInfoGrafico(num_candles=num_candles, start_date=0, end_date=0)
                # zonas = self.analyzer.get_grouped_highs_lows(dataframe, group_size, show_debug=False)
                resultados = analyzer.analisarTodosIndicadores(dataframe, 0)
                if analyzer.existe_ordem_aberta() and var_move_stop.get():
                    analyzer.move_stop(70, 30)

                if len(resultados) > 0:
                    for resultado in analyzer.filtrarPorMinutosEPreco(resultados, qtd_minutes):
                        data, entrada, tipo, stop, take, metodo, timestamp = resultado
                        print()
                        print(
                            f"############################################ ORDEM DEFINIDA #####################################################################")
                        horarioBrasilia = datetime.strptime(data, "%d/%m/%Y %H:%M") - timedelta(hours=6)
                        print(
                            f"Resultados nos ultimos {qtd_minutes} min: {(horarioBrasilia)} - {tipo} - {entrada} - {metodo} - Robot {analyzer.login}")
                        print(
                            f"############################################ ORDEM DEFINIDA #####################################################################")

                resultadoFiltrado = analyzer.filtrarPorMinutosEPreco(resultados, qtd_minutes)
                if len(resultadoFiltrado) > 0:
                    sinaisGerenciados = signalManagement.adicionar_sinais(resultadoFiltrado)
                    for res in sinaisGerenciados:
                        data, entrada, tipo, stop, take, metodo, timestamp, sinalId = res
                        if not signalManagement.ja_executado(sinal_id=sinalId):
                            print()
                            print(
                                f"############################################ ENVIAR ORDEM ################################################################################")
                            horarioBrasilia = datetime.strptime(data, "%d/%m/%Y %H:%M") - timedelta(hours=6)
                            print(
                                f"Ordem: {(horarioBrasilia)} - {tipo} - {entrada} - {metodo} - Robot {analyzer.login}")
                            analyzer.executarOrdemImediata(tipo, stop, take)
                            signalManagement.marcar_como_executado(sinal_id=sinalId)
                            print(
                                f"############################################ ENVIAR ORDEM ################################################################################")
                    # else:
                    # print(f"Sem resultados - Robot - {analyzer.login}")
                time.sleep(30)

    except Exception as e:
        messagebox.showerror("Erro", f"Ocorreu um erro:\n{e}")


# GUI Setup
janela = tk.Tk()
janela.title("Executor de Robô MT5")
janela.geometry("720x600")

# Layout row tracker
linha = 0
coluna = 0


def _impedir_reposo():
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001
    ES_DISPLAY_REQUIRED = 0x00000002

    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )


def criar_label_entrada(texto, valor_default=""):
    global linha, coluna
    tk.Label(janela, text=texto).grid(row=linha, column=coluna, padx=5, pady=5, sticky="w")
    campo = tk.Entry(janela, width=25)
    campo.insert(0, valor_default)
    campo.grid(row=linha + 1, column=coluna, padx=5, pady=5)
    coluna += 1
    if coluna > 2:
        coluna = 0
        linha += 2
    return campo


def criar_checkbox(texto, valor_default=False):
    global linha, coluna
    var = tk.BooleanVar(value=valor_default)
    cb = tk.Checkbutton(janela, text=texto, variable=var)
    cb.grid(row=linha, column=coluna, padx=5, pady=5, sticky="w")
    coluna += 1
    if coluna > 2:
        coluna = 0
        linha += 1
    return var


# Campos de entrada
var_credencial = criar_label_entrada("Chave de Acesso:", "8618b90c-6372-5560-be78-666666669819")
entry_login = criar_label_entrada("Login:", "550163421")
entry_senha = criar_label_entrada("Senha:", "2222222")
entry_servidor = criar_label_entrada("Servidor:", "FTMO-Server5")
entry_symbol = criar_label_entrada("Símbolo:", "XAUUSD")
entry_timeframe = criar_label_entrada("Timeframe (ex: M5):", "M5")
entry_volume = criar_label_entrada("Volume:", "0.01")
data_inicio = criar_label_entrada("Data Início Simulação:", "01/01/2025")
data_fim = criar_label_entrada("Data Fim Simulação:", "20/05/2025")

# Checkboxes (3 por linha também)
var_macd = criar_checkbox("Habilitar MACD", True)
var_cci = criar_checkbox("Habilitar CCI", True)
var_rsi = criar_checkbox("Habilitar RSI", True)
var_bollinger = criar_checkbox("Habilitar Bollinger", True)
var_pattern = criar_checkbox("Análise de Padrões", True)
var_divergence = criar_checkbox("Verificar Divergência", True)
var_move_stop = criar_checkbox("Habilitar Move Stop", True)
var_enable_sim = criar_checkbox("Habilitar Simulação", False)

# Parâmetros numéricos adicionais
entry_martingale = criar_label_entrada("Martingale:", "300")
entry_stop_minimo = criar_label_entrada("Stop Mínimo:", "300")
entry_perda_diaria = criar_label_entrada("Máx. Perda Diária:", "0")
entry_percent_risk = criar_label_entrada("Percentual Risco/Lucro:", "100")

# Botão
linha += 2
tk.Button(
    janela,
    text="Executar Robô",
    command=executar_robot,
    bg="green",
    fg="white",
    height=2,
    width=30
).grid(row=linha, column=0, columnspan=3, pady=20)

janela.mainloop()
