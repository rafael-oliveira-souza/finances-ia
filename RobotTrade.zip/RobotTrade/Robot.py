from datetime import datetime

import MetaTrader5 as mt5

from CandleAnalyzer import CandleAnalyzer
from RobotExecutor import RobotExecutor
from UUIDManager import UUIDManager

analisadorAccount2 = CandleAnalyzer(login=550163421, senha='v!2Rk3@8', servidor='FTMO-Server5',
                                    symbol="XAUUSD", timeframe=mt5.TIMEFRAME_M5, volume=0.04,
                                    enableMACD=True, enableCCI=True, enableRSI=True,
                                    enableBollinger=True, enablePatternAnalysis=True, enableVerifyDivergence=True,
                                    enableMartingale=300, stopMinimo=300, maximoPerdaDiaria=0,
                                    percentRiskAndProfit=80)

executor = RobotExecutor(
    analyzers=[
        analisadorAccount2
    ],
    enableMoveStop=True,
    enableSimulation=True,
    dataInicio=datetime(2025, 6, 1),
    dataFim=datetime.now()
)

gestor = UUIDManager()
# uid = gestor.codificar(f'JORNADA_ROBOT_TRADE_RAFAEL_SILVA', datetime(2025, 1, 1), datetime(2025, 8, 10))
# print("UUID:", uid)
#
# result = gestor.decodificar(uid)
# print("UUID como objeto:", result)

executor.execute()
